function checkname()
{
var fname=document.getElementById('name').value
var firstname=/^[A-Za-z]{3,15}$/;
if(firstname.test(fname))
{

 return true
}
else
{

alert("Please enter a valid name");
 return false
}
}
function checksalary()
{
var salary=document.getElementById('salary').value
var salarycheck=/^[0-9]{1,20}$/;	
if(salarycheck.test(salary))
{

return true
}
else
{
alert("Ennter a valid salary");
return false
}	
}
function checkdepartment()
{
var department=document.getElementById('department').value
var departmentcheck=/^[A-Za-z]{2,15}$/;
if(departmentcheck.test(department))
{
 return true
}
else
{
alert("Please enter a valid Department name");
 return false
}
}
function validate()
{ 
 var name=checkname();
   if(name==true)
   {   
   }
else
{   
	alert("Please enter a valid name");
	return false
}
var salary=checksalary();
   if(salary==true)
   {   
   }
else
{   
	alert("Please enter a valid Slary");
	return false
}
var department=checkdepartment();
   if(department==true)
   {   
   }
else
{   
	alert("Please enter a valid Department name");
	
	return false
}

}